<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hotel_booking";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    exit();
}

// Handle form submission
$errors = [];
$success = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname = filter_input(INPUT_POST, 'fullname', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];
    $phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_STRING);
    $address = filter_input(INPUT_POST, 'address', FILTER_SANITIZE_STRING);
    
    // Field-specific validation
    if (empty($fullname)) $errors['fullname'] = "Full name is required";
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors['email'] = "Valid email is required";
    if (strlen($password) < 6) $errors['password'] = "Password must be at least 6 characters";
    if (empty($phone)) $errors['phone'] = "Phone number is required";
    
    if (empty($errors)) {
        try {
            $password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (fullname, email, password, phone, address) VALUES (:fullname, :email, :password, :phone, :address)");
            $stmt->execute([
                'fullname' => $fullname,
                'email' => $email,
                'password' => $password,
                'phone' => $phone,
                'address' => $address
            ]);
            $success = "Registration successful!";
            header("Location: login.php");
            exit();
            $_POST = [];
        } catch(PDOException $e) {
            if($e->getCode() == 23000 && str_contains($e->getMessage(), 'email')){
                 $errors['email'] = "This email is already registered. Try login instead.";
            } else {     
            $errors['general'] = "Registration failed: " . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hotel Booking - Login</title>
    <link rel="stylesheet" href="style.css">
    <?php include_once('client/header.php') ?>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #6e8efb, #a777e3);
            min-height: 110vh;
            display: flex;
            justify-content: center;
            align-items: anchor-center;
          
        }

        .container {
            background: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 1.5rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
            position: relative;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            color: #555;
        }

        input {
            width: 100%;
            padding: 0.8rem;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1rem;
        }

        input:focus {
            outline: none;
            border-color: #4A90E2;
            box-shadow: 0 0 5px rgba(74,144,226,0.3);
        }

        .error {
            color: #D32F2F;
            font-size: 0.8rem;
            margin-top: 0.3rem;
            display: block;
            position: absolute;
        }

        .success {
            color: #2E7D32;
            font-size: 0.9rem;
            margin-bottom: 1rem;
            text-align: center;
        }

        button {
            width: 100%;
            padding: 0.8rem;
            background: linear-gradient(135deg, #6e8efb, #a777e3);
            border: none;
            border-radius: 5px;
            color: white;
            font-size: 1rem;
            cursor: pointer;
            transition: background 0.3s;
        }

        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        }
        .links {
            text-align: center;
            margin-top: 1rem;
        }

        .links a {
            color: #4A90E2;
            text-decoration: none;
        }

        .links a:hover {
            text-decoration: underline;
        }
        

        @media (max-width: 480px) {
            .container {
                margin: 1rem;
                padding: 1.5rem;
            }
        }









          *{
        margin: 0;
        padding: 0;                         /* This Header css */
        font-family: 'Popins',sans-serif;
        }
        nav{
            position: fixed;
            width: 100%;                    /* main parent*/
            padding: 0px 0;                     
            background:#ecf0f3;
            z-index: 1000;
            box-shadow: 0px 2px 5px rgba(0,0,0,0.1);
        }
        nav .menu{
            width: 100%;
            height: 55px;
            padding: 0 12px;
            display: flex;
            justify-content: space-between;         /* menu under add content */
            align-items: center;
            
        }
        .menu .logo a{
            font-size: 29px;
            font-weight: 600;
            text-decoration: none;              /* munu under logo under anchor tag */
            list-style: none;
            margin-left: 38px;
        }
        .menu .logo li{
            list-style: none;          /* menu logo ni under li */
        }
        .menu ul{
            list-style: none;           /* menu ul */
            display: flex;
            align-items: center;
        }
        .menu ul a{
            margin: 0 12px;
            text-decoration: none;      /* menu ul anchor */
            font-size: 18px;
            color: #31344b  ;
            font-weight: 400;
            display: inline-flex;
            padding: 10px 12px;
        
        }
        .menu ul a:hover{
            color: #2196F3;         /* main ul hover button */
        }
        nav label.button{
                color: #31344b;
                font-size: 18px;
                cursor: pointer;        /* nav label button */
                position: absolute;
                display: none;
        }
        nav label.cancel{
            position: absolute;
            top: 25px;              /* nav label cancel */
            right: 30px;
        }
        #check{
            display: none;      /* hameborger hover button */
        }
        img{
            height: auto;       /* image  */
            width: 100%;
        }
        auth-button {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            gap: 12px;
            padding-right: 66px;
            list-style: none;
            margin: 0;
        }

        .auth-button li {
            list-style: none;
        }

        .auth-button a {
            padding: 6px 26px;
            font-size: 16px;
            font-weight: 600;
            border: 1px solid #ccc;
            background-color: #fff;
            cursor: pointer;
            text-decoration: none;
            color: #000;
            transition: 0.3s;
            display: inline-block;
        }

        .auth-button a:hover {
            background-color: #eee;
        }

        /* Special styling for Sign Up */
        #lg {
            border-radius: 20px;
            background: #2196F3;
            color: #630d8b;
            height: 44px;
            margin-top:2px;
        }


        #lg:hover{
            color: white;           /* button under id #lg:hover */ 
        } */
        #logo{
            display: flex;
            justify-content: flex-start;
            list-style: none;               /* under logo RiverBook */ 
            margin-left: 34px;
        } 
    </style>
</head>
<body>
    
        <nav>
                <div class="menu">
                        <input type="checkbox" id="check">
                        <div class="logo"> <li><a href="#">HotelBook</a></li></div>
                        <ul>    
                                <!-- <label  class="button cancel" for="check"><i class="fas fa-times"></i></label> 
                                <li><a href="index.php">HOME</a></li>
                                <li><a href="#">ABOUT</a></li>
                                <li><a href="#">OUR ROOM</a></li>
                                <li><a href="#">BLOG</a></li>
                                <li><a href="#">CONTACT US</a></li> -->
                               <ul class="auth-button">
                                         <li><a href="register.php" id="lg">Sign Up</a></li>
                                         <li><a href="login.php" id="lg" class="login-btn">Login</a></li>
                                </ul>

                        </ul>
                        <label class="button bars" for="check"><i class="fas fa-bars"></i></label>
                </div>
               
        </nav>

    <div class="container">
        <h2>Register</h2>
        <?php if ($success): ?>
            <div class="success"><?php echo $success; ?></div>
        <?php endif; ?>
        <?php if (isset($errors['general'])): ?>
            <div class="error"><?php echo $errors['general']; ?></div>
        <?php endif; ?>
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="form-group">
                <label for="fullname">Full Name</label>
                <input type="text" id="fullname" name="fullname" value="<?php echo isset($_POST['fullname']) ? htmlspecialchars($_POST['fullname']) : ''; ?>">
                <?php if (isset($errors['fullname'])): ?>
                    <span class="error"><?php echo $errors['fullname']; ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                <?php if (isset($errors['email'])): ?>
                    <span class="error"><?php echo $errors['email']; ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password">
                <?php if (isset($errors['password'])): ?>
                    <span class="error"><?php echo $errors['password']; ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="tel" id="phone" name="phone" value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>">
                <?php if (isset($errors['phone'])): ?>
                    <span class="error"><?php echo $errors['phone']; ?></span>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <label for="address">Address</label>
                <input type="text" id="address" name="address" value="<?php echo isset($_POST['address']) ? htmlspecialchars($_POST['address']) : ''; ?>">
            </div>
            <button type="submit">Register</button>
            <div class="links">
                <p>Already have an account? <a href="login.php">Log in</a></p>
                <p><a href="index.php">Back to Home</a></p>
            </div>
        </form>
    </div>
<body>