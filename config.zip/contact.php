<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/fontawesome-free-6.5.2-web/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- header section -->
    <nav>     
          <div class="menu">
                  <input type="checkbox" id="check">
                  <div class="logo"> <li><a href="#">HotelBook</a></li></div>
                  <ul>    
                          <label  class="button cancel" for="check"><i class="fas fa-times"></i></label> 
                          <li><a href="index.php">HOME</a></li>
                          <li><a href="#">ABOUT</a></li>
                          <li><a href="#">ROOMS</a></li>
                          <li><a href="#">BLOG</a></li>
                          <li><a href="contact.php">CONTACT US</a></li>
                          <ul class="auth-button">
                                    <li><a href="register.php" id="lg">Sign Up</a></li>
                                    <li><a href="login.php" id="lg" class="login-btn">Login</a></li>
                          </ul>

                  </ul>
                  <label class="button bars" for="check"><i class="fas fa-bars"></i></label>
          </div>       
  </nav>
<!-- Contact Section -->
  <section id="contact" class="contact-section">
    <div class="contact-container">
      <div class="contact-image">
        <img src="public/room1fr.jpg" alt="OM Restaurant">
      </div>
      <div class="contact-form">
        <h2>Contact Us</h2>
        <form action="/send" method="post">
          <input type="text" name="name" placeholder="Your Name" required>
          <input type="tel" name="phone" placeholder="Phone Number" required>
          <input type="email" name="email" placeholder="Email Address" required>
          <textarea name="message" rows="5" placeholder="Your Message" required></textarea>
          <button type="submit">Send Message</button>
        </form>
      </div>
    </div>
  </section>
</body>
</html>