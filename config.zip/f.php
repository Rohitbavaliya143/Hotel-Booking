<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Hotel Booking</title>
  <link rel="stylesheet" href="css/fontawesome-free-6.5.2-web/css/all.min.css">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="style2.css">
  <link rel="stylesheet" href="style3.css">
  <style>
    .booking-form {
      position: relative;
      z-index: 1;
      background: #fff;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      width: 300px;
      text-align: center;
      margin: 0 auto;
    }
    .booking-form h2 {
      margin-bottom: 20px;
      color: #333;
    }
    .booking-form label {
      display: block;
      margin: 10px 0 5px;
      color: #333;
    }
    .booking-form input {
      width: 100%;
      padding: 10px;
      margin-bottom: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }
    .booking-form button {
      width: 100%;
      padding: 10px;
      background: linear-gradient(to right, #6b48ff, #b174ff);
      color: #fff;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
    .booking-form button:hover {
      background: linear-gradient(to right, #5a3de6, #9d5fff);
    }
    .full-width-image {
      width: 100%;
      margin-top: 20px;
    }
    .full-width-image img {
      width: 100%;
      height: auto; /* Normal height */
      display: block;
      border-radius: 10px;
    }
    .rooms-button {
      width: 100%;
      padding: 10px;
      margin-top: 20px;
      background: linear-gradient(to right, #6b48ff, #b174ff);
      color: #fff;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      text-align: center;
      font-size: 16px;
    }
    .rooms-button:hover {
      background: linear-gradient(to right, #5a3de6, #9d5fff);
    }




    .container {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
        }
        .section {
            width: 80%;
            margin: 1px 0;
            text-align: center;
            background-color: #fff;
            padding: 10px;

            border-radius: 5px;
        }
        .section img {
            max-width: 100%;
            height: auto;
        }
        .btn {
            
            
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .btn:hover {
            background-color: #FFC107;
        }
        @media (max-width: 600px) {
            .section {
                width: 95%;
          }
        }
  </style>
</head>
<body>
  <div class="hero-section">
    <?php include_once('client/header.php') ?>
    <!-- Replace with your image path -->
    <img src="public/booking.jpg" alt="Hotel Room" class="hero-image">

    <div class="booking-form">
      <h2>Book Your Stay</h2>
      <form action="submit_booking.php" method="POST">
        <label for="checkin">Check-in:</label>
        <input type="datetime-local" id="checkin" name="checkin" required>

        <label for="checkout">Check-out:</label>
        <input type="datetime-local" id="checkout" name="checkout" required>

        <label for="guests">Guests:</label>
        <input type="number" id="guests" name="guests" min="1" max="10" required>

        <button type="submit">Book Now</button>
      </form>
      <!-- Full-width image below Book Now button -->
      <div class="full-width-image">
        <img src="public/room-preview.jpg" alt="Room Preview">
      </div>
      <!-- Full-width Rooms button -->
      <a href="rooms.php"><button class="rooms-button">Rooms</button></a>
    </div>
  </div>
   
  <section class="room-section">
    <h2>AC Rooms</h2>
    <div class="room-grid">
      <div class="room-card">
        <div class="room-image"><img src="public/room1fr.jpg" alt="style"></div>
        <p id="sec">₹ 2,000</p> 
      </div>
      <div class="room-card">
        <div class="room-image"><img src="public/room2fr.jpg" alt="style"></div>
        <p id="sec">₹ 2,500</p>
      </div>
      <div class="room-card">
        <div class="room-image"><img src="public/room3fr.jpg" alt="style"></div>
        <p id="sec">₹ 3,000</p>
      </div>
    </div>

    <h2>Non-AC Rooms</h2>
    <div class="room-grid">
      <div class="room-card">
        <div class="room-image"><img src="public/Nonacroom1.jpg" alt="style"></div>
        <p id="sec">₹ 1,000</p>
      </div>
      <div class="room-card">
        <div class="room-image"><img src="public/Nonacroom2.jpg" alt="style"></div>
        <p id="sec">₹ 1,500</p>
      </div>
      <div class="room-card">
        <div class="room-image"><img src="public/Nonacroom3.jpg" alt="style"></div>
        <p id="sec">₹ 2,000</p>
      </div>
    </div>
  </section> -->
  <!-- Footer Section
  <footer class="site-footer">
    <link rel="stylesheet" href="footer.css">
    <div class="footer-content">
      <div class="footer-about">
        <h3>HotelBook</h3>
        <p>Booking.</p>
      </div>
      <div class="footer-links">
        <h4>Quick Links</h4>
        <ul>
          <li><a href="#">Home</a></li>
          <li><a href="#">About</a></li>
          <li><a href="#">Rooms</a></li>
          <li><a href="#">Contact</a></li>
        </ul>
      </div>
      <div class="footer-contact-info">
        <h4>Get in Touch</h4>
        <p>📞 <a href="tel:+919313167770">+91 93131 67770</a></p>
        <p>📧 <a href="mail-to:rohitbavaliya3@gmail.com">rohitbavaliya3@gmail.com</a></p>
        <p>📍 Chotila, Surendranagar, Gujarat</p>
      </div>
      <div class="footer-social">
        <h4>Follow Us</h4>
        <a href="#"><img src="https://img.icons8.com/ios/24/ffffff/facebook--v1.png"/></a>
        <a href="#"><img src="https://img.icons8.com/ios/24/ffffff/instagram-new.png"/></a>
        <a href="#"><img src="https://img.icons8.com/ios/24/ffffff/twitter-squared.png"/></a>
      </div>
    </div>
    <div class="footer-bottom">
      <p>© 2025 HotelBook. All rights reserved. <a href="#">Privacy Policy</a> | <a href="#">Terms of Use</a></p>
    </div>
  </footer>
</body>
</html>