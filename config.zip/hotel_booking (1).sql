-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 18, 2025 at 09:36 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotel_booking`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `resettoken` varchar(255) DEFAULT NULL,
  `resettokenexpire` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `email`, `password`, `phone`, `address`, `created_at`, `resettoken`, `resettokenexpire`) VALUES
(1, 'Rohit Bavaliya', 'r3@gmail.com', '$2y$10$aHywtzCxP1DtZ1natrZpc.NZYOiusmGvVLXbuh3k.PHHE3fG0Ii12', '9313167770', 'surendranagar', '2025-07-14 06:34:22', NULL, NULL),
(8, 'paresh', 'rohit3@gmail.com', '$2y$10$jGc0dM28jZUtN9KYTrlL4uRsaM7XINoXMz32R81YzPnkT6g8dFL6O', 'fffff', 'gggg', '2025-07-15 07:13:05', NULL, NULL),
(17, 'hardik malakiya', 'hardik3@gmail.com', '$2y$10$gx.Opqhpa9eXkOIQwTH5Oerflza6x6RQIFoerpHQH5hK8aSipjctq', '787878', 'chotila', '2025-07-17 06:50:55', NULL, NULL),
(26, 'rohit8', 'rohitbavaliya3@gmail.com', '$2y$10$I7.bwlcOf4RWdFN0kqAKiOIFtD/SG.LVvHbPw7Mc1s1/G782lmjcu', '8999988999', 'chotila', '2025-07-18 05:24:11', ' 6fc1b13af963c4ecf7c037b9a2c9b33b', '2025-07-18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
