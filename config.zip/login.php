<?php
session_start(); // Start session for user authentication
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hotel_booking";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    exit();
}

// Handle form submission
$errors = [];
$success = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $password = $_POST['password'];
    
    // Server-side validation
    if (empty($username)) {
        $errors['username'] = "Username is required";
    }
    if (empty($password)) {
        $errors['password'] = "Password is required";
    }
    
    if (empty($errors)) {
        try {
            $stmt = $conn->prepare("SELECT id, fullname, password FROM users WHERE fullname = :username");
            $stmt->execute(['username' => $username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['fullname'] = $user['fullname'];
                $success = "Login successful! Welcome, " . htmlspecialchars($user['fullname']) . "!";
                // Redirect to homepage after login (uncomment to enable)
                header("Location: index.php");
                exit();
            } else {
                $errors['general'] = "Invalid username or password";
            }
        } catch(PDOException $e) {
            $errors['general'] = "Login failed: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hotel Booking - Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
   
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #6e8efb, #a777e3);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: anchor-center;
        }

        .container {
            background: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 1.5rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
            position: relative;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            color: #555;
        }

        input {
            width: 100%;
            padding: 0.8rem;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1rem;
        }

        input:focus {
            outline: none;
            border-color: #4A90E2;
            box-shadow: 0 0 5px rgba(74,144,226,0.3);
        }

        .error {
            color: #D32F2F;
            font-size: 0.8rem;
            margin-top: 0.3rem;
            display: block;
            position: absolute;
        }

        .success {
            color: #2E7D32;
            font-size: 0.9rem;
            margin-bottom: 1rem;
            text-align: center;
        }

        button {
            width: 100%;
            padding: 0.8rem;
            background: linear-gradient(135deg, #6e8efb, #a777e3);
            border: none;
            border-radius: 5px;
            color: white;
            font-size: 1rem;
            cursor: pointer;
            transition: background 0.3s;
            visibility: visible;
        }

        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        }

        button:disabled {
            background: #cccccc;
            cursor: not-allowed;
        }

        .links {
            text-align: center;
            margin-top: 1rem;
        }

        .links a {
            color: #4A90E2;
            text-decoration: none;
        }

        .links a:hover {
            text-decoration: underline;
        }
        .form-group p{
            margin-top:1vh;
        }
        .hidden {
            display: none;
        }
        .link {
            color: #6b48ff;
            text-decoration: none;
            cursor: pointer;
        }

        @media (max-width: 480px) {
            .container {
                margin: 1rem;
                padding: 1.5rem;
            }
        }







         *{
        margin: 0;
        padding: 0;                         /* This Header css */
        font-family: 'Popins',sans-serif;
        }
        nav{
            position: fixed;
            width: 100%;                    /* main parent*/
            padding: 0px 0;                     
            background:#ecf0f3;
            z-index: 1000;
            box-shadow: 0px 2px 5px rgba(0,0,0,0.1);
        }
        nav .menu{
            width: 100%;
            height: 55px;
            padding: 0 12px;
            display: flex;
            justify-content: space-between;         /* menu under add content */
            align-items: center;
            
        }
        .menu .logo a{
            font-size: 29px;
            font-weight: 600;
            text-decoration: none;              /* munu under logo under anchor tag */
            list-style: none;
            margin-left: 38px;
        }
        .menu .logo li{
            list-style: none;          /* menu logo ni under li */
        }
        .menu ul{
            list-style: none;           /* menu ul */
            display: flex;
            align-items: center;
        }
        .menu ul a{
            margin: 0 12px;
            text-decoration: none;      /* menu ul anchor */
            font-size: 18px;
            color: #31344b  ;
            font-weight: 400;
            display: inline-flex;
            padding: 10px 12px;
        
        }
        .menu ul a:hover{
            color: #2196F3;         /* main ul hover button */
        }
        nav label.button{
                color: #31344b;
                font-size: 18px;
                cursor: pointer;        /* nav label button */
                position: absolute;
                display: none;
        }
        nav label.cancel{
            position: absolute;
            top: 25px;              /* nav label cancel */
            right: 30px;
        }
        #check{
            display: none;      /* hameborger hover button */
        }
        img{
            height: auto;       /* image  */
            width: 100%;
        }
        auth-button {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            gap: 12px;
            padding-right: 66px;
            list-style: none;
            margin: 0;
        }

        .auth-button li {
            list-style: none;
        }

        .auth-button a {
            padding: 6px 26px;
            font-size: 16px;
            font-weight: 600;
            border: 1px solid #ccc;
            background-color: #fff;
            cursor: pointer;
            text-decoration: none;
            color: #000;
            transition: 0.3s;
            display: inline-block;
        }

        .auth-button a:hover {
            background-color: #eee;
        }

        /* Special styling for Sign Up */
        #lg {
            border-radius: 15px;
            color: #630d8b;
            height: 43px;
            margin-top:18px;
            padding-bottom:32px;
            font-size:15px;
        }


        #lg:hover{
            color:blue;           /* button under id #lg:hover */ 
        } */
        #logo{
            display: flex;
            justify-content: flex-start;
            list-style: none;               /* under logo RiverBook */ 
            margin-left: 34px;
        } 
    </style>
</head>
<body>
     <nav>
                <div class="menu">
                        <input type="checkbox" id="check">
                        <div class="logo"> <li><a href="#">HotelBook</a></li></div>
                        <ul>    
                                <!-- <label  class="button cancel" for="check"><i class="fas fa-times"></i></label> 
                                <li><a href="index.php">HOME</a></li>
                                <li><a href="#">ABOUT</a></li>
                                <li><a href="#">OUR ROOM</a></li>
                                <li><a href="#">BLOG</a></li>
                                <li><a href="#">CONTACT US</a></li> -->
                               <ul class="auth-button">
                                         <li><a href="register.php" id="lg">Sign Up</a></li>
                                         <li><a href="login.php" id="lg" class="login-btn">Login</a></li>
                                </ul>

                        </ul>
                        <label class="button bars" for="check"><i class="fas fa-bars"></i></label>
                </div>
               
        </nav>
    <div class="container">
        <?php if ($success): ?>
            <div class="success"><?php echo $success; ?></div>
        <?php endif; ?>
        <?php if (isset($errors['general'])): ?>
            <div class="error"><?php echo $errors['general']; ?></div>
        <?php endif; ?>
        <form id="loginForm" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
             <h2>Login</h2>
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>">
                <span class="error" id="usernameError"><?php echo isset($errors['username']) ? $errors['username'] : ''; ?></span>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password">    
                <span class="error" id="passwordError"><?php echo isset($errors['password']) ? $errors['password'] : ''; ?></span>
                 <div class="form-group">
                    <a href="#" class="link" onclick="showForgotForm()">Forgot Password? Forgot</a>
                </div>
            </div>
            <button type="submit" id="submitBtn">Login</button>
             <div class="links">
                <p>Don't have an account? <a href="register.php">Register</a></p>    
             </div>
        </form>
       

        <div id="forgot-form" class="hidden">
            <form action="forgotpassword.php" method="POST">
                <h2>Forgot Password</h2>
                <div class="form-group">
                    <input type="email" placeholder="Email" name="email">
                </div>
                <div class="form-group">
                    <button class="btn" name="send-reset-link">Send Link</button>
                </div>
                <div><a href="#" class="link" onclick="showLoginForm()">Back to Login</a></div>
            </form>    
        </div>
     <script>
        function showForgotForm() {
            document.getElementById('loginForm').classList.add('hidden');
            document.getElementById('forgot-form').classList.remove('hidden');
        }
         function showLoginForm() {
             document.getElementById('forgot-form').classList.add('hidden');
            document.getElementById('loginForm').classList.remove('hidden');
         }
         function submitForgot() {
         }
    </script>

</body>
</html>