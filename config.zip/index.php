<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Hotel Booking</title>
  <link rel="stylesheet" href="css/fontawesome-free-6.5.2-web/css/all.min.css">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="style2.css">
  <link rel="stylesheet" href="style3.css">
</head>
    <style>
      .container {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
        }
        .section {
            width: 80%;
            margin: 1px 0;
            text-align: center;
            background-color: #fff;
            padding: 10px;

            border-radius: 5px;
        }
        .section img {
            max-width: 100%;
            height: auto;
        }
        .btn {
            
            
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .btn:hover {
            background-color: #FFC107;
        }
        @media (max-width: 600px) {
            .section {
                width: 95%;
          }
        }
    </style>
<body>

<!-- Navbar Section -->
  <nav>     
          <div class="menu">
                  <input type="checkbox" id="check">
                  <div class="logo"> <li><a href="#">HotelBook</a></li></div>
                  <ul>    
                          <label  class="button cancel" for="check"><i class="fas fa-times"></i></label> 
                          <li><a href="index.php">HOME</a></li>
                          <li><a href="#">ABOUT</a></li>
                          <li><a href="#">ROOMS</a></li>
                          <li><a href="#">BLOG</a></li>
                          <li><a href="contact.php">CONTACT US</a></li>
                          <ul class="auth-button">
                                    <li><a href="register.php" id="lg">Sign Up</a></li>
                                    <li><a href="login.php" id="lg" class="login-btn">Login</a></li>
                          </ul>

                  </ul>
                  <label class="button bars" for="check"><i class="fas fa-bars"></i></label>
          </div>       
  </nav>

 <!-- Booking Form Section -->     
  <div class="hero-section">
    <img src="public/booking.jpg" alt="Hotel Room" class="hero-image">
    <div class="half-image">
      <form action="">
        <img src="public/room1fr.jpg" alt="style">
        <button class="img">Book Now</button>
      </form>
    </div>
    <div class="booking-form">
      <h2>Book Your Stay</h2>
      <form action="submit_booking.php" method="POST">
        <label for="checkin">Check-in:</label>
        <input type="datetime-local" id="checkin" name="checkin" required>

        <label for="checkout">Check-out:</label>
        <input type="datetime-local" id="checkout" name="checkout" required>

        <label for="guests">Guests:</label>
        <input type="number" id="guests" name="guests" min="1" max="10" required>

        <button type="submit">Book Now</button>
      </form>
    </div>
  </div>

  <!-- Containar Section -->
   <div class="container">
        <div class="section">
            <img src="public/ac room.jpg" alt="Image 1">
        </div>
        <div class="section">
            <button class="btn" onclick="window.location.href='non-ac.html'">Book AC Room</button>
        </div>
        <div class="section">
            <img src="public/not ac room.jpg" alt="Image 2">
        </div>
        <div class="section">
            <button class="btn" onclick="window.location.href='another-page.html'">Book Non-Ac Room</button>
        </div>
    </div>
  
  <!-- Contact Section-->
  <section id="contact" class="contact-section">
    <div class="contact-container">
      <div class="contact-image">
        <img src="public/room1fr.jpg" alt="Hotel Booking">
      </div>
      <div class="contact-form">
        <h2>Contact Us</h2>
        <form action="/send" method="post">
          <input type="text" name="name" placeholder="Your Name" required>
          <input type="tel" name="phone" placeholder="Phone Number" required>
          <input type="email" name="email" placeholder="Email Address" required>
          <textarea name="message" rows="5" placeholder="Your Message" required></textarea>
          <button type="submit">Send Message</button>
        </form>
      </div>
    </div>
  </section>

<!-- Footer Section -->
  <footer class="site-footer">
    <link rel="stylesheet" href="footer.css">
    <div class="footer-content">
      <div class="footer-about">
        <h3>HotelBook</h3>
        <p>Booking.</p>
      </div>
      <div class="footer-links">
        <h4>Quick Links</h4>
        <ul>
          <li><a href="#">Home</a></li>
          <li><a href="#">About</a></li>
          <li><a href="#">Rooms</a></li>
          <li><a href="contact.php">Contact</a></li>
        </ul>
      </div>
      <div class="footer-contact-info">
        <h4>Get in Touch</h4>
        <p>📞 <a href="tel:+919313167770">+91 93131 67770</a></p>
        <p>📧 <a href="mailto:rohitbavaliya3@gmail.com">rohitbavaliya3@gmail.com</a></p>
        <p>📍 Chotila, Surendranagar, Gujarat</p>
      </div>
      <div class="footer-social">
        <h4>Follow Us</h4>
        <a href="#"><img src="https://img.icons8.com/ios/24/ffffff/facebook--v1.png"/></a>
        <a href="#"><img src="https://img.icons8.com/ios/24/ffffff/instagram-new.png"/></a>
        <a href="#"><img src="https://img.icons8.com/ios/24/ffffff/twitter-squared.png"/></a>
      </div>
    </div>
    <div class="footer-bottom">
      <p>© 2025 HotelBook. All rights reserved. <a href="#">Privacy Policy</a> | <a href="#">Terms of Use</a></p>
    </div>
  </footer>

</body>
</html>
