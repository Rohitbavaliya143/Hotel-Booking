<?php
    $conn=mysqli_connect("localhost","root","","hotel_booking");
    if($conn)
    {
        echo("connection ok");
    }
    else
    {
        echo("connection fail");
    }
?>