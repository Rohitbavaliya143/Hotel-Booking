<!-- <!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Online Book</title> -->
 <!--</head>
<body> -->
        <nav>
                
                <div class="menu">
                        <input type="checkbox" id="check">
                        <div class="logo"> <li><a href="#">HotelBook</a></li></div>
                        <ul>    
                                <label  class="button cancel" for="check"><i class="fas fa-times"></i></label> 
                                <li><a href="index.php">HOME</a></li>
                                <li><a href="#">ABOUT</a></li>
                                <li><a href="#">ROOMS</a></li>
                                <li><a href="#">BLOG</a></li>
                                <li><a href="#">CONTACT US</a></li>
                               <ul class="auth-button">
                                         <li><a href="register.php" id="lg">Sign Up</a></li>
                                         <li><a href="login.php" id="lg" class="login-btn">Login</a></li>
                                </ul>

                        </ul>
                        <label class="button bars" for="check"><i class="fas fa-bars"></i></label>
                </div>
               
        </nav>
 <!-- </body>
</html>  -->